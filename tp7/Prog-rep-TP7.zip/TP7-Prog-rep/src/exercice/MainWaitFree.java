package exercice;

public class MainWaitFree {
	public static void main(String[] args) {
		
		int nb = 20;
		
		// On crée un tableau de taille 20 et initialisé à 0 (de type Snap)
		
		WaitfreeSnap<Integer> Valpartage = new WaitfreeSnap<Integer>(nb, new Integer(0));
		
		// On crée un tableau de thread
		MyThreadWaitFree tabTreads[] = new MyThreadWaitFree[nb];
		
		// Initialisation de tout les threads
		for (int i = 0; i < nb; i++)
			tabTreads[i] = new MyThreadWaitFree(Valpartage, nb);
		try {
			for (int i = 0; i < nb; i++) {
				// On lance les threads
				tabTreads[i].start();
				if (i != 0)
					tabTreads[i].join(); // On Bloque la thread appelant jusqu'à ce que le thread représenté par cette instance s'arrête,
			}
			tabTreads[0].join();
		} catch (InterruptedException e) {};
	}
}
