package exercice;

public class MyThreadWaitFree extends Thread {
	
	public WaitfreeSnap<Integer> Valpartage;
	public int nb;

	public MyThreadWaitFree(WaitfreeSnap<Integer> Valpartage, int nb) {
		this.Valpartage = Valpartage;
		this.nb = nb;
	}

	// la méthode run() 
	public void run() {
		// Dans le cas ou la est diffèrente de 0 (TreadID 0), on fait l'update
		if (ThreadID.get() != 4) {
			System.out.println("Update de la Thread " + ThreadID.get() + " : ");
			Valpartage.update(new Integer(1));
			Valpartage.update(new Integer(2));
			Valpartage.update(new Integer(3));

		}
		// Si la est égale à 0, on recupere le tableau à l'aide de la méthode scan et on fait le contenu
		else {
			Object[] Obj = new Object[nb];
			Obj = Valpartage.scan();
			for (int i = 0; i < nb; i++) {
				System.out.println("scan de " + ThreadID.get() + ": " + (Integer) Obj[i] + " ");
			}
			
		}
	}
}
