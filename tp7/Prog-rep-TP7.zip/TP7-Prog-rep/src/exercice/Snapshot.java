/**
* TP n2 V n1 :
*
* Titre du TP : Snapshot
*
* Date :01/03/2020
*
* Nom : Jabeur
* Pr�nom : Soufien
* N� d'�tudiant : 21956753
*
* email : soufien.jabeur@etu.univ-paris-diderot.fr
*
*Nom: Kaba
*Pr�nom: Saran
*N� d'�tudiant: 21605980
*
*email: skaba1606@gmail.com
* Remarques :
*/
package exercice;

public interface Snapshot<T> {
	public void update(T v);
	public T[] scan();
}
