/**
* TP n2 V n1 :
*
* Titre du TP : Snapshot
*
* Date :01/03/2020
*
* Nom : Jabeur
* Pr�nom : Soufien
* N� d'�tudiant : 21956753
*
* email : soufien.jabeur@etu.univ-paris-diderot.fr
*
*Nom: Kaba
*Pr�nom: Saran
*N� d'�tudiant: 21605980
*
*email: skaba1606@gmail.com
* Remarques :
*/
package exercice;

public class ThreadID {
	static volatile int nextID = 0;

	private static class ThreadLocalID extends ThreadLocal<Integer> {
		@Override
		protected synchronized Integer initialValue() {
			return nextID++;
		}
	}

	private static final ThreadLocal<Integer> threadID = new ThreadLocal<Integer>() {
		@Override
		protected synchronized Integer initialValue() {
			return nextID++;
		}
	};

	public static int get() {
		return threadID.get();
	}

	public static void set(int index) {
		threadID.set(index);
	}
}
