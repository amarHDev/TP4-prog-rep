package exercice;

public class Elem <T> {
	
	public T value; // Valeur qui incrémente à chaque Snapshot
	public T[] snap; // Le Snapshot le plus recent
	
	// Consturteur qui sert à initialiser la valeur
	public Elem(T value){
		this.value=value;
		snap=null;
	}
	
	// Constructeur qui sert à initialiser le tableau de snap et la valeur
	public Elem(T value, T[] snap){
		this.value=value;
		this.snap=snap;
	}
}
