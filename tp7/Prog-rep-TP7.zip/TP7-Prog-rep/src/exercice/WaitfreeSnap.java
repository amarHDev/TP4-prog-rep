package exercice;

import java.util.concurrent.atomic.AtomicStampedReference;

public class WaitfreeSnap<T> implements Snapshot<T> {

	private AtomicStampedReference<Elem<T>>[] a_table;
	public WaitfreeSnap(int capacity, T init) {
		
		// On instancie le tableau a_table de taille égale au capacity
		a_table = new AtomicStampedReference[capacity];
		
		// On declare un tableau de snap
		T[] tabsnap = (T[]) new Object[capacity];
		
		// Remplissage de tableau e snap
		for (int i = 0; i < capacity; i++) {
		 tabsnap[i] = init;
		}
		// Remplissage de tableau a_table avec snap=initsnap et value=init
		for (int i = 0; i < capacity; i++) {
			Elem e = new Elem(init, tabsnap);
			a_table[i] = new AtomicStampedReference<Elem<T>>(e, 0);
		}
	}

	@Override
	public void update(T w) {
		
		// On recupere l'ID de chaque thread
		int threadcourante = ThreadID.get();
		
		// On recupere la valeur courante de stamp
		int stampCourant = a_table[threadcourante].getStamp();
		
		System.out.println("Je suis la Thread " + threadcourante + "!! je faitl'update et j'écrit " + w + " et stamp est de " + stampCourant);
		
		// On fait le scan
		T[] lscan = scan();
		Elem<T> tab = new Elem<T>(w, lscan);
		a_table[threadcourante].set(tab, stampCourant + 1);
	}

	// Cette méthode va faire une copie sur le tableau a_table
	private AtomicStampedReference[] collect() {

		AtomicStampedReference<Elem<T>>[] copyRef = new AtomicStampedReference[a_table.length];
		for (int j = 0; j < a_table.length; j++) {
			// On retourne la reference courant
			copyRef[j] = a_table[j];
			try {
				MyThreadWaitFree.sleep(5);
			} catch (InterruptedException e) {};
			MyThreadWaitFree.yield();
		}
		return copyRef;
	}

	@Override
	public T[] scan() {
		// On declare les deux collect
		AtomicStampedReference<Elem<T>>[] vieuxscan, newscan;
		boolean[] moved = new boolean[a_table.length];
		// On recupere l'ancien scan
		vieuxscan = collect();
		collect: while (true) {
			newscan = collect();
			for (int i = 0; i < a_table.length; i++) {
				// Si on n'a pas le même stamp dans les deux stamp
				if (vieuxscan[i].getStamp() != newscan[i].getStamp()) {
					// si la thread a changé deux fois, prendre son second snapshot
					if (moved[i]) {
						return (T[]) newscan[i].getReference().snap;
					} else {
						moved[i] = true;
						vieuxscan = newscan;
						continue collect;
					}
				}
				return (T[]) getValues(newscan);
			}

		}
	}

	public T[] getValues(AtomicStampedReference<Elem<T>>[] T) {
		T[] copy = (T[]) new Object[T.length];
		for (int i = 0; i < T.length; i++) {
			copy = T[i].getReference().snap;
		}
		return copy;
	}
}
